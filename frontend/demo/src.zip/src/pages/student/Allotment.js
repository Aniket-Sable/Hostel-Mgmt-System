import React from 'react'

function Allotment() {
    return (
        <div>
            
        </div>
    )
}
export default Allotment;