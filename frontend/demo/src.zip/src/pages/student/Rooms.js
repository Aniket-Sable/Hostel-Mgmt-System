import React from 'react'

 function Rooms() {
    return (
        <div>
            
        </div>
    )
}
export default Rooms;