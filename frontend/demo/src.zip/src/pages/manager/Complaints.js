import React, { useState, useEffect } from 'react';
import axios from 'axios'
import { Card } from 'react-bootstrap';
import RectHome from './RectHome';
import { BrowserRouter as Router, Route } from 'react-router-dom';

// import { query } from '../../../../../Backend/database';

export default function Complaints() {
    <Route path='/Dash/home' component={RectHome} />


    const [query, setquery] = useState([]);

    useEffect(() => {

        axios.get("http://localhost:3001/api/users/user/isloggedin").then((response) => {

            console.log(response.status)
            if (response.status === 200) {

                axios.get("http://localhost:3001/api/users/login/queries").then((response) => {
                    console.log(response.data);
                    setquery(response.data.data)

                });
            }

        })
            .catch(error => {
                console.log(error);
                document.location.href = '/Dash/home'
            })


    }, [])


    return (
        <>

            {
                query.map(query => (
                    <div className="row">
                        <div className="column">
                            <div className="mard">
                                <div>
                                    <Card.Body>
                                        {/* <Card.Title>Dated: {notification.date}</Card.Title> */}
                                        <Card.Subtitle className="">{query.email}</Card.Subtitle>
                                        <Card.Text>
                                            Room No : {query.roomno}
                                        </Card.Text>
                                        <Card.Text>
                                            {query.comment}
                                        </Card.Text>

                                    </Card.Body>
                                </div>
                            </div>
                        </div>
                    </div>
                ))
            }

        </>
    )
}
