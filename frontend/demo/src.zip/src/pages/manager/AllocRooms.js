import React from 'react'

function AllocRooms() {
    return (
        <div>
            
        </div>
    )
}
export default AllocRooms;