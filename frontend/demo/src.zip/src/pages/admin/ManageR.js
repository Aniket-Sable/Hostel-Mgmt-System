import React from 'react'

function ManageR() {
  return (
   <>
   </>
  )
}

export default ManageR