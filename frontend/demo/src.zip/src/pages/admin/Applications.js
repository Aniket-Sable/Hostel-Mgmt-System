import React, { useState, useEffect } from 'react'
import axios from 'axios';
import Button from '@restart/ui/esm/Button';
// import './RecDash.css';
import ReactHTMLTableToExcel from 'react-html-table-to-excel';
// import Footer from './Footer'

export default function Applications() {

    const [profileData, setProfileData] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:3001/api/admin/getfirstapplications").then((response) => {
            console.log(response.data);
            setProfileData(response.data)


        });
    }, [])


    // const sort = () => {
    //     axios.get("http://localhost:3001/api/users/reclogin/allocated").then((response) => {
    //         console.log(response.data);
    //         setProfileData(response.data.data)


    //     });
    // }

    // const sortmale = () => {
    //     axios.get("http://localhost:3001/api/users/reclogin/maleallocated").then((response) => {
    //         console.log(response.data);
    //         setProfileData(response.data.data)


    //     });
    // }

    // const sortfemal = () => {
    //     axios.get("http://localhost:3001/api/users/reclogin/femaleallocated").then((response) => {
    //         console.log(response.data);
    //         setProfileData(response.data.data)


    //     });
    // }

    return (
        <div className="container">
            {/* <button type="submit" className="formFieldButton sort" onClick={sort}>Sort</button>
            <button type="submit" className="formFieldButton male" onClick={sortmale}>Get Boys Application</button>
            <button type="submit" className="formFieldButton male" onClick={sortfemal}>Get Girls Application</button>             */}
            <div className="row mt-4">

            
                <ReactHTMLTableToExcel
                    id="test-table-xls-button"
                    className="download-table-xls-button btn btn-success mb-3"
                    table="table-to-xls"
                    filename="tablexls"
                    sheet="tablexls"
                    buttonText="Download Data" />
                <table className="table" id="table-to-xls">
                    <thead className="thead-dark">
                        <tr className='table-row'>
                            <th>Name</th>
                            <th>PRN</th>
                            <th>Email</th>
                            <th>Contact No</th>
                            <th>Year</th>
                            <th>Branch</th>
                            <th>Previous Exam</th>
                            <th>Score</th>
                            <th>Category</th>
                            <th>Gender</th>
                            <th>Admission Receipt</th>
                            <th>Marksheet</th>
                            {/* <th>Cast</th> */}
                            {/* <th>Gender</th> */}
                        </tr>
                    </thead>
                    <tbody>

                        {profileData.map((profile) =>
                            <tr>
                                <td>{profile.name}</td>
                                <td>{profile.prn}</td>
                                <td>{profile.email}</td>
                                <td>{profile.phoneno}</td>
                                <td>{profile.course}</td>
                                <td>{profile.branch}</td>
                                <td>{profile.preexam}</td>
                                <td>{profile.prescore}</td>
                                <td>{profile.category}</td>
                                <td>{profile.gender}</td>
                                <td>{profile.addmarksheet}</td>
                                <td>{profile.addreceipt}</td>
                                <img src={profile.addreceipt} />
                                {/* <td>{profile.castcertificate}</td> */}
                                {/* <td>{profile.dob}</td> */}
                            </tr>
                        )}

                    </tbody>
                </table>
            </div>
        </div>
    );



}
