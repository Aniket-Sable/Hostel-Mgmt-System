import React from "react";
import Container from "@material-ui/core/Container";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { Form, Col, Row, Card } from 'react-bootstrap';
import { Component, useState } from "react";


export const Academic = ({ formData, setForm, navigation }) => {
  let { course, branch, preexam, prescore, addmissionreceipt, previousmarksheet, castcertificate, category } = formData;

  // let [selectedfile, setselectedfile] = useState({
  //   addmissionreceipt: "",
  //   previousmarksheet: "",
  //   castcertificate: ""

  // });

  // addmissionreceipt = selectedfile.addmissionreceipt;
  // previousmarksheet = selectedfile.previousmarksheet;
  // castcertificate = selectedfile.castcertificate;

  // console.log(addmissionreceipt);

  console.log(category);
  function onFileSelect(e) {
    // const files = { ...selectedfile };
    // console.log(files);
    formData[e.target.id] = e.target.files[0];
    // console.log(files)
    // setselectedfile(files);
    // console.log(files);
  }


  return (
    <>
      <h2 className="personal">Academic Details</h2>
      <Container >
        <Form>
          <Row>
            <Form.Group as={Col} controlId="formGridState">
              <Form.Label>Year of Study</Form.Label>
              <Form.Select defaultValue="Choose..." value={course} name="course" onChange={setForm}>
                <option>Choose...</option>
                <option>First Year Diploma</option>
                <option>Second Year Diploma</option>
                <option>Third Year Diploma</option>
                <option>First Year B.Tech</option>
                <option>Second Year B.Tech</option>
                <option>Third Year B.Tech</option>
                <option>Final Year B.Tech</option>
                <option>First Year M.Tech</option>
                <option>Second Year M.Tech</option>
              </Form.Select>
            </Form.Group>





            <Form.Group as={Col} controlId="formGridState">
              <Form.Label>Branch</Form.Label>
              <Form.Select defaultValue="Choose..." value={branch} name="branch" onChange={setForm}>
                <option>Choose...</option>
                <option>Civil</option>
                <option>Electrical</option>
                <option>Electronics</option>
                <option>Mechanical</option>
                <option>Computer Science</option>
                <option>Information Technology</option>
              </Form.Select>
            </Form.Group>
          </Row>

          <Row className="city">

            {(() => {
              switch (course) {

                case 'First Year Diploma':

                  return (
                    <Form.Group as={Col} controlId="formGridState">
                      <Form.Label>Previous Year Exam (On which basis you got the admission in wce)</Form.Label>
                      <Form.Select defaultValue="Choose..." value={preexam} name="preexam" onChange={setForm}>
                        <option>SSC</option>
                      </Form.Select>
                    </Form.Group>
                  )

                case 'Second Year Diploma':

                  return (
                    <Form.Group as={Col} controlId="formGridState">
                      <Form.Label>Previous Year Exam (On which basis you got the admission in wce)</Form.Label>
                      <Form.Select defaultValue="Choose..." value={preexam} name="preexam" onChange={setForm}>
                        <option>First Year Diploma</option>
                      </Form.Select>
                    </Form.Group>
                  )

                case 'Third Year Diploma':

                  return (
                    <Form.Group as={Col} controlId="formGridState">
                      <Form.Label>Previous Year Exam (On which basis you got the admission in wce)</Form.Label>
                      <Form.Select defaultValue="Choose..." value={preexam} name="preexam" onChange={setForm}>
                        <option>Second Year Diploma</option>
                      </Form.Select>
                    </Form.Group>
                  )
                case 'First Year B.Tech':

                  return (
                    <Form.Group as={Col} controlId="formGridState">
                      <Form.Label>Previous Year Exam (On which basis you got the admission in wce)</Form.Label>
                      <Form.Select defaultValue="Choose..." value={preexam} name="preexam" onChange={setForm}>
                        {/* <option>Choose...</option> */}
                        <option>HSC</option>
                        <option>CET</option>
                        {/* <option>Third Year Diploma</option> */}
                      </Form.Select>
                    </Form.Group>
                  )
                case 'Second Year B.Tech':

                  return (
                    <Form.Group as={Col} controlId="formGridState">
                      <Form.Label>Previous Year Exam (On which basis you got the admission in wce)</Form.Label>
                      <Form.Select defaultValue="Choose..." value={preexam} name="preexam" onChange={setForm}>
                        <option>First Year B.Tech</option>
                        <option>Third Year Diploma</option>
                      </Form.Select>
                    </Form.Group>
                  )
                case 'Third Year B.Tech':

                  return (
                    <Form.Group as={Col} controlId="formGridState">
                      <Form.Label>Previous Year Exam (On which basis you got the admission in wce)</Form.Label>
                      <Form.Select defaultValue="Choose..." value={preexam} name="preexam" onChange={setForm}>
                        <option>Second Year B.Tech</option>
                      </Form.Select>
                    </Form.Group>
                  )

                case 'Final Year B.Tech':

                  return (
                    <Form.Group as={Col} controlId="formGridState">
                      <Form.Label>Previous Year Exam (On which basis you got the admission in wce)</Form.Label>
                      <Form.Select defaultValue="Choose..." value={preexam} name="preexam" onChange={setForm}>
                        <option>Third Year B.Tech</option>
                      </Form.Select>
                    </Form.Group>

                  )
                case 'First Year M.Tech':

                  return (
                    <Form.Group as={Col} controlId="formGridState">
                      <Form.Label>Previous Year Exam (On which basis you got the admission in wce)</Form.Label>
                      <Form.Select defaultValue="Choose..." value={preexam} name="preexam" onChange={setForm}>
                        <option>B.Tech</option>
                      </Form.Select>
                    </Form.Group>

                  )
                case 'Second Year M.Tech':

                  return (
                    <Form.Group as={Col} controlId="formGridState">
                      <Form.Label>Previous Year Exam (On which basis you got the admission in wce)</Form.Label>
                      <Form.Select defaultValue="Choose..." value={preexam} name="preexam" onChange={setForm}>
                        <option>First Year M.Tech</option>
                      </Form.Select>
                    </Form.Group>


                  )
              }
            })()}


            {/* ///////// Pre Score////////// */}

            {(() => {
              switch (course) {

                case 'First Year Diploma':
                  return (
                    <Form.Group as={Col} controlId="formGridZip">
                      <Form.Label>Enter SSC Score</Form.Label>
                      <Form.Control placeholder="For Ex. 91.40" value={prescore} name="prescore" onChange={setForm} />
                    </Form.Group>
                  )
                case 'Second Year Diploma':
                  return (
                    <Form.Group as={Col} controlId="formGridZip">
                      <Form.Label>Enter First Year Diploma Score</Form.Label>
                      <Form.Control placeholder="For Ex. 91.40"
                        value={prescore} name="prescore" onChange={setForm} />
                    </Form.Group>
                  )
                case 'Third Year Diploma':
                  return (
                    <Form.Group as={Col} controlId="formGridZip">
                      <Form.Label>Enter Second Year Diploma Score</Form.Label>
                      <Form.Control placeholder="For Ex. 91.40" value={prescore} name="prescore" onChange={setForm} />
                    </Form.Group>
                  )

                case 'First Year B.Tech':
                  return (
                    <Form.Group as={Col} controlId="formGridZip">
                      <Form.Label>Enter {preexam}  Score</Form.Label>
                      {(() => {

                        if (preexam === 'HSE') {
                          return (
                            <Form.Control placeholder="For Ex. 75.23" value={prescore} name="prescore" onChange={setForm} />
                          )
                        }
                        else if (preexam === 'CET') {
                          return (
                            <Form.Control placeholder="For Ex. 91.8141190" value={prescore} name="prescore" onChange={setForm} />
                          )
                        }
                        else if (preexam === 'Third Year Diploma') {
                          return (
                            <Form.Control placeholder="For Ex. 91.81" value={prescore} name="prescore" onChange={setForm} />
                          )
                        }

                      })()}
                    </Form.Group>
                  )
                case 'Second Year B.Tech':
                  return (
                    <Form.Group as={Col} controlId="formGridZip">
                      <Form.Label>Enter First Year B.Tech Score (CGPA)</Form.Label>
                      <Form.Control placeholder="For Ex. 8.41" value={prescore} name="prescore" onChange={setForm} />
                    </Form.Group>
                  )
                case 'Third Year B.Tech':
                  return (
                    <Form.Group as={Col} controlId="formGridZip">
                      <Form.Label>Enter Second Year B.Tech Score (CGPA)</Form.Label>
                      <Form.Control placeholder="For Ex. 8.41" value={prescore} name="prescore" onChange={setForm} />
                    </Form.Group>
                  )
                case 'Final Year B.Tech':
                  return (
                    <Form.Group as={Col} controlId="formGridZip">
                      <Form.Label>Enter Third Year B.Tech Score (CGPA)</Form.Label>
                      <Form.Control placeholder="For Ex. 8.41" value={prescore} name="prescore" onChange={setForm} />
                    </Form.Group>
                  )
                case 'First Year M.Tech':
                  return (
                    <Form.Group as={Col} controlId="formGridZip">
                      <Form.Label>Enter Final Year B.Tech Score</Form.Label>
                      <Form.Control placeholder="For Ex. 8.41" value={prescore} name="prescore" onChange={setForm} />
                    </Form.Group>
                  )
                case 'Second Year M.Tech':
                  return (
                    <Form.Group as={Col} controlId="formGridZip">
                      <Form.Label>Enter First Year M.Tech Score</Form.Label>
                      <Form.Control placeholder="For Ex. 8.41" value={prescore} name="prescore" onChange={setForm} />
                    </Form.Group>
                  )
              }
            })()}
          </Row>

          <Row>
            <Form.Group as={Col}>
              <Form.Label>Score Card of Previous Year</Form.Label>
              <Form.Control type="file" id="previousmarksheet" name="previousmarksheet" onChange={(e) => onFileSelect(e)} />
            </Form.Group>
            <Form.Group as={Col} >
              <Form.Label>Admission Receipt</Form.Label>
              <Form.Control type="file" id="addmissionreceipt" name="addmissionreceipt" onChange={(e) => onFileSelect(e)} />
            </Form.Group>

            {(() => {

              if (category != 'General') {
                return (
                  <Form.Group as={Col}>
                    <Form.Label>Cast Certificate</Form.Label>
                    <Form.Control type="file" id="castcertificate" name="castcertificate" onChange={(e) => onFileSelect(e)} />
                  </Form.Group>
                )
              }
            })()}

          </Row>

          <div style={{ marginTop: "1rem" }}>
            <Button
              color="secondary"
              variant="contained"
              className="back"
              style={{ color: "rgb(137 45 255)" }}
              onClick={() => navigation.previous()}
            >
              Back
            </Button>
            <Button
              className="notification next"
              color="primary"
              variant="contained"
              onClick={() => navigation.next()}
            >
              Next
            </Button>
          </div>
        </Form>
      </Container>
    </>
  );
};