import React from "react";
import Container from '@material-ui/core/Container';

export const Submit = ({ formData, navigation }) => {
 
    
  return (
    <Container maxWidth="sm" style={{ marginTop: '4rem' }}>
      <h2>Thank you for submitting, we will be in touch!</h2>
    
    </Container>
  );
};