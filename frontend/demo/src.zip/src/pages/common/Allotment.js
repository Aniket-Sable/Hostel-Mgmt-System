import React from 'react'

function Allotment() {
  return (
    <div>Allotment</div>
  )
}

export default Allotment