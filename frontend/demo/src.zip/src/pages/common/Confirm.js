import React from "react";
import  MultiSteps  from "./Confirm/Steps";

function Confirm() {
  return (
    <div className="App">
      <MultiSteps />
    </div>
  );
}

export default Confirm;