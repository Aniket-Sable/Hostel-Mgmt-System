import React from 'react'

function Footer() {
    return (
        <div>
            <div className="footer-stud"><h5 className="footer-text">A Portal for Hostel Room Allocation and Management | Copyright@2021</h5></div>
        </div>
    )
}
export default Footer;